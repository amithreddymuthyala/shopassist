package com.application.shopassist.ui.favourites

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import com.application.shopassist.R
import com.application.shopassist.database.ShopAssistDatabase
import com.application.shopassist.database.dao.FavouritesDao
import com.application.shopassist.database.models.Favourites
import kotlinx.android.synthetic.main.recycler_view.*

class FavouritesFragment : Fragment() {

    private lateinit var favouritesViewModel: FavouritesViewModel
    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var favouritesList:List<Favourites>
    private lateinit var favouritesDao: FavouritesDao
    private lateinit var db: ShopAssistDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        favouritesViewModel =
            ViewModelProviders.of(this).get(FavouritesViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_favourites, container, false)
            // Allowing main thread queries, just for testing.

        return root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // RecyclerView node initialized here
        list_recycler_view.apply {
            // set a LinearLayoutManager to handle Android
            // RecyclerView behavior
            linearLayoutManager = LinearLayoutManager(activity)
            // set the custom adapter to the RecyclerView
            db = ShopAssistDatabase.getInstance(context)
            favouritesDao = db.favouritesDao
            favouritesList=favouritesDao.getAll()
            adapter = List
        }
    }

    fun getFavourites(){

    }

}