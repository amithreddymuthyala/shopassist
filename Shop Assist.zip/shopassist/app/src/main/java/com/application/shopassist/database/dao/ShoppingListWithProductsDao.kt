package com.application.shopassist.database.dao

import androidx.room.*
import com.application.shopassist.database.models.ShoppingListProductCrossRef
import com.application.shopassist.database.models.ShoppingListWithProducts

@Dao
interface ShoppingListWithProductsDao {

    @Transaction
    @Query("SELECT * FROM table_shopping_list")
    fun getShoppingListWithProducts():List<ShoppingListWithProducts>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(join: ShoppingListProductCrossRef)


}