package com.application.shopassist.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.application.shopassist.database.models.Favourites
import com.application.shopassist.database.models.ProductsDb

@Dao
interface ProductDbDao {
    @Insert
    fun insert(product: ProductsDb)
    @Update
    fun update(product: ProductsDb)

    @Query("select * from table_products where productId=:key")
    fun getProductById(key:Long): ProductsDb

    @Query("select * from table_products where product_name=:key")
    fun getProductByName(key:String): ProductsDb

    @Query("select * from table_products")
    fun getAll(): List<ProductsDb>

    @Query("DELETE FROM table_products")
    fun deleteAll ()

    @Query("DELETE FROM table_products where productId=:key")
    fun delete(key:Long)


}