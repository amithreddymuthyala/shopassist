package com.application.shopassist.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.application.shopassist.database.models.Favourites
import com.application.shopassist.database.models.ShoppingList

@Dao
interface ShoppingListDao {

    @Insert
    fun insert(list: ShoppingList)

    @Update
    fun update(list: ShoppingList)

    @Query("select * from table_shopping_list where shoppingListId=:key")
    fun getById(key:Long): ShoppingList

    @Query("select * from table_shopping_list where list_name =:name")
    fun getByName(name:String): ShoppingList

    @Query("select * from table_shopping_list")
    fun getAll(): List<ShoppingList>

    @Query("DELETE FROM table_shopping_list")
    fun deleteAll ()

    @Query("DELETE FROM table_shopping_list where shoppingListId=:key")
    fun delete(key:Long)


}