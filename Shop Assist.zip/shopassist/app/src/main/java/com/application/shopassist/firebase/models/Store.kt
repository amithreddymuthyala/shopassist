package com.application.shopassist.firebase.models



class Store (
    var name:String="",
    var productPrice:Double=0.00,
    var quantity:String="",
    var priceUpdatedDate: String= ""

)