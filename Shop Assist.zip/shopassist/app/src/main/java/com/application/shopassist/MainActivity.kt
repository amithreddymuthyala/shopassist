    package com.application.shopassist

    import android.content.Intent
    import android.os.Bundle
    import android.util.Log
    import android.view.Menu
    import android.view.MenuItem
    import com.google.android.material.bottomnavigation.BottomNavigationView
    import androidx.appcompat.app.AppCompatActivity
    import androidx.navigation.findNavController
    import androidx.navigation.ui.AppBarConfiguration
    import androidx.navigation.ui.setupActionBarWithNavController
    import androidx.navigation.ui.setupWithNavController
    import com.application.shopassist.database.dao.FavouritesDao
    import com.application.shopassist.firebase.dao.FirebaseCallback
    import com.application.shopassist.firebase.GlobalProducts
    import com.application.shopassist.firebase.dao.ProductDataManager
    import com.application.shopassist.firebase.models.Product

    class MainActivity : AppCompatActivity() {

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)
            val navView: BottomNavigationView = findViewById(R.id.nav_view)

            val navController = findNavController(R.id.nav_host_fragment)
            // Passing each menu ID as a set of Ids because each
            // menu should be considered as top level destinations.
            val appBarConfiguration = AppBarConfiguration(
                setOf(
                    R.id.navigation_favourites, R.id.navigation_shoppinglist, R.id.navigation_pricecomparison
                )
            )
            setupActionBarWithNavController(navController, appBarConfiguration)
            navView.setupWithNavController(navController)
            navView.itemIconTintList = null
            getAndSetProductsFromFireBase()

        }

        override fun onCreateOptionsMenu(menu: Menu?): Boolean {
            val inflater = menuInflater
            inflater.inflate(R.menu.mymenu,menu)
            return super.onCreateOptionsMenu(menu)
        }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            when(item.itemId){
             R.id.item1 -> {
                 var intent: Intent = Intent(this, displaytext::class.java )
                 startActivity(intent)
                    return true
             }
                R.id.item2 -> {
                    //TODO: Implement location feature over here
                    return true
                }
            }
            return super.onOptionsItemSelected(item)
        }

        fun getAndSetProductsFromFireBase(){
            ProductDataManager.getProducts(object:
                FirebaseCallback {
                override fun onAsyncDataRetrieval(list: MutableList<Product>) {
                    GlobalProducts.productList=list
                    for(product in  GlobalProducts.productList){
                        Log.i("Main",product.barcode)
                    }
                }
            })

        }




    }
