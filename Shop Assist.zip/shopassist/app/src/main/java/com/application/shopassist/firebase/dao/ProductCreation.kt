//package com.application.shopassist.firebase.dao
//
//import com.application.shopassist.firebase.models.Product
//import com.application.shopassist.firebase.models.Store
//
////class ProductCreation() {
//
//
//    companion object {
//        val availableProducts: List<Product> = mutableListOf(
//            Product(
//                "Salt", "Spices", "", mutableListOf(
//                    Store
//                        ("Walmart",0.78,"100gm","2020-03-06"),
//                    Store
//                        ("Sobeys",0.79,"100gm","2020-03-06"),
//                    Store
//                        ("Shoppers Drug Mart",0.80,"100gm","2020-03-06")
//                )
//            )
//            ,
//            Product(
//                "Turmeric powder", "Spices", "", mutableListOf(
//                    Store
//                        ("Walmart",1.52,"100gm","2020-03-06"),
//                    Store
//                        ("Sobeys",1.61,"100gm","2020-03-06"),
//                    Store
//                        ("Shoppers Drug Mart",1.3,"100gm","2020-03-06")
//                )
//            ),
//            Product(
//                "Chilli powder", "Spices", "", mutableListOf(
//                    Store
//                        ("Walmart",1.31,"100gm","2020-03-06"),
//                    Store
//                        ("Sobeys",1.51,"100gm","2020-03-06"),
//                    Store
//                        ("Shoppers Drug Mart",1.42,"100gm","2020-03-06")
//                )
//            ),
//            Product(
//                "Black pepper", "Spices", "", mutableListOf(
//                    Store
//                        ("Walmart",2.17,"100gm","2020-03-06"),
//                    Store
//                        ("Sobeys",2.23,"100gm","2020-03-06"),
//                    Store
//                        ("Shoppers Drug Mart",2.10,"100gm","2020-03-06")
//                )
//            )
//        )
//        fun createProducts() {
//            ProductDataManager.createProducts(availableProducts)
//        }
//    }
//
//
//
//
//}